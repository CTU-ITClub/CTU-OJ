def longest_increasing_subsequence(arr):
    n = len(arr)
    dp = [1] * n  # Khởi tạo mảng dp, tất cả đều có thể tạo thành dãy con tăng dài nhất chỉ chứa chính nó

    for i in range(1, n):
        for j in range(i):
            if arr[i] > arr[j]:
                dp[i] = max(dp[i], dp[j] + 1)

    return max(dp)  # Trả về độ dài của dãy con tăng dài nhất

# Đọc đầu vào
n = int(input())
arr = list(map(int, input().split()))

# Gọi hàm và in kết quả
result = longest_increasing_subsequence(arr)
print(result)