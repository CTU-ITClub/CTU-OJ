#include <bits/stdc++.h>

using namespace std;

#define ever ;;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    for (ever);

    int a, b;

    cin >> a >> b;

    cout << a + b;
    
    return 0;
}