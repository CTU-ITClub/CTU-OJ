#include <iostream>
#include <vector>
#include <queue>
#include <climits>

using namespace std;

const int INF = INT_MAX;

// Đỉnh và trọng số cạnh
struct Edge {
    int to;
    int weight;
};

// Hàm tìm đường đi ngắn nhất từ nguồn đến đích
void Dijkstra(vector<vector<Edge>>& graph, int source, int destination) {
    int n = graph.size();
    vector<int> distance(n, INF);
    vector<int> parent(n, -1);
    distance[source] = 0;

    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    pq.push(make_pair(0, source));

    while (!pq.empty()) {
        int u = pq.top().second;
        int dist_u = pq.top().first;
        pq.pop();

        if (dist_u > distance[u]) {
            continue;
        }

        for (const Edge& edge : graph[u]) {
            int v = edge.to;
            int weight = edge.weight;

            if (distance[u] + weight < distance[v]) {
                distance[v] = distance[u] + weight;
                parent[v] = u;
                pq.push(make_pair(distance[v], v));
            }
        }
    }

    // In đường đi ngắn nhất và khoảng cách
    if (distance[destination] == INF) {
        cout << "No path from " << source + 1 << " to " << destination + 1 << "\n";
    } else {
        cout << "Shortest distance from vertex " << source + 1 << " to vertex " << destination + 1 << ": " << distance[destination] << "\n";
        cout << "Shortest path: ";
        int curr = destination;
        vector<int> path;
        while (curr != -1) {
            path.push_back(curr);
            curr = parent[curr];
        }
        for (int i = path.size() - 1; i >= 0; i--) {
            cout << path[i];
            if (i != 0) {
                cout << " -> ";
            }
        }
        cout << "\n";
    }
}

int main() {
    int n, m;
    cin >> n >> m;
    vector<vector<Edge>> graph(n);

    for (int i = 0; i < m; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        graph[u - 1].push_back({v - 1, w}); // Chuyển về 0-based index
    }

    int source, destination;
    cin >> source >> destination;
    Dijkstra(graph, source - 1, destination - 1); // Chuyển về 0-based index

    return 0;
}