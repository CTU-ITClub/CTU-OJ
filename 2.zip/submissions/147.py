def find_longest_increasing_subsequence(arr):
    n = len(arr)
    dp = [1] * n
    backtrack = [-1] * n
    max_len = 1
    end_idx = 0

    for i in range(n):
        for j in range(i):
            if arr[i] > arr[j] and dp[i] < dp[j] + 1:
                dp[i] = dp[j] + 1
                backtrack[i] = j
        if dp[i] > max_len:
            max_len = dp[i]
            end_idx = i

    longest_subsequence = []
    while end_idx != -1:
        longest_subsequence.append(arr[end_idx])
        end_idx = backtrack[end_idx]

    longest_subsequence.reverse()
    return longest_subsequence

# Đọc dữ liệu đầu vào
n = int(input())
arr = list(map(int, input().split()))

# Tìm và in ra dãy con tăng dài nhất
result = find_longest_increasing_subsequence(arr)
print(" ".join(map(str, result)))