"Hạng","Tên truy cập","Tên đầy đủ","Điểm","ctu_xxx"
"1","thangved02","Minh Thắng","100","100"
"Total AC","1"